clear; clc;
load data.mat
load S.mat
load one-step-result.mat
% X = [Si(1:999) S'];                % one-step prediction

% X = [Si(2:701) ; predict(2:299)];    % two-step prediction
X = [Si(1:998) S(: , 1:998)'];

X = zscore(X);
Y = Si(3:1000);

SVM(X, Y);
