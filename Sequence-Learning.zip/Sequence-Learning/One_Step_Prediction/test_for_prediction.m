load one_step_result.mat
load data_ICA_one_step.mat
real = Y(701:997);
pred = predict(3:end);           % delay one period
%% Figure
figure(1)
plot(real,'LineWidth',1);hold on;
plot(pred,'r','LineWidth',1);
legend('real','predict','FontSize',10);xlabel('n');ylabel('Si Wt%');
title('one step prediction');
grid on;
%% RNew: fitting index
Q = sum((real - pred).^2);
Y = sum(real.^2);
Rnew = 1 - (Q / Y)^(1 / 2)
%% successful rate of prediction
% range of allowable error: +- 25%
count = 0;
for i = 1:size(pred, 1)
    low = real(i) - 0.25;
    high = real(i) + 0.25;
    if (pred(i) > low & pred(i) < high)
        count = count + 1;
    end
end
fprintf('successful rate of prediction within the range of error 25%%: %d\n', count / size(pred, 1));
% range of allowable error: +- 20%
count = 0;
for i = 1:size(pred, 1)
    low = real(i) - 0.2;
    high = real(i) + 0.2;
    if (pred(i) > low & pred(i) < high)
        count = count + 1;
    end
end
fprintf('successful rate of prediction within the range of error 20%%: %d\n', count / size(pred, 1));
% range of allowable error: +- 15%
count = 0;
for i = 1:size(pred, 1)
    low = real(i) - 0.15;
    high = real(i) + 0.15;
    if (pred(i) > low & pred(i) < high)
        count = count + 1;
    end
end
fprintf('successful rate of prediction within the range of error 15%%: %d\n', count / size(pred, 1));
% range of allowable error: +- 10%
count = 0;
for i = 1:size(pred, 1)
    low = real(i) - 0.1;
    high = real(i) + 0.1;
    if (pred(i) > low & pred(i) < high)
        count = count + 1;
    end
end
fprintf('successful rate of prediction within the range of error 10%%: %d\n', count / size(pred, 1));
% range of allowable error: +- 8%
count = 0;
for i = 1:size(pred, 1)
    low = real(i) - 0.08;
    high = real(i) + 0.08;
    if (pred(i) > low & pred(i) < high)
        count = count + 1;
    end
end
fprintf('successful rate of prediction within the range of error 8%%: %d\n', count / size(pred, 1));
% range of allowable error: +- 5%
count = 0;
for i = 1:size(pred, 1)
    low = real(i) - 0.05;
    high = real(i) + 0.05;
    if (pred(i) > low & pred(i) < high)
        count = count + 1;
    end
end
fprintf('successful rate of prediction within the range of error 5%%: %d\n', count / size(pred, 1));
%% successful rate of prediction for tredency of Si Content
real_trend = real(2:size(real,1)) - real(1:size(real,1)-1);
pred_trend = pred(2:size(pred,1)) - real(1:size(pred,1)-1);
for i = 1:size(real_trend,1)
    if(real_trend(i) >= 0)
        real_trend(i) = 1;
    end
    if(real_trend(i) < 0)
        real_trend(i) = -1;
    end
end
for i = 1:size(pred_trend,1)
    if(pred_trend(i) >= 0)
        pred_trend(i) = 1;
    end
    if(pred_trend(i) < 0)
        pred_trend(i) = -1;
    end
end
count = 0;
for i = 1:size(pred_trend,1)
    if(pred_trend(i) == real_trend(i))
        count = count + 1;
    end
end
fprintf('successful rate of prediction for trendency of Si Content: %d\n', count / size(pred_trend, 1));