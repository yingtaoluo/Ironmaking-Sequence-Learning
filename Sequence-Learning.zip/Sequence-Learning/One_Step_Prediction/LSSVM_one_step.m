clear;
clc;
%% ========================== load data ===========================
load data_ICA_one_step.mat
sh = X;
[m,n] = size(sh);
ts = Y;
tsx = X;
original = ts(length(sh)*0.7+1:end,:);

% Draw the original graphic of the stock price
figure;
plot(ts,'LineWidth',1);
title('Si Content before mapping','FontSize',12);xlabel('n');ylabel('Si Wt%');
grid on;

fprintf('Plot the Si content before mapping.\n');
fprintf('Program paused. Press enter to continue.\n');
pause;

%data preprocessing
ts = ts';
tsx = tsx';
%% ========================= mapping ==============================
% mapminmax is an mapping function in matlab
%Use mapminmax to do mapping
[TS,TSps] = mapminmax(ts);
% The scale of the data from 1 to 2
TSps.ymin = 1;
TSps.ymax = 2;
%normalization
[TS,TSps] = mapminmax(ts,TSps);

% plot the graphic of the Si Content after mapping
figure;
plot(TS,'LineWidth',1);
title('Si Content after mapping','FontSize',12);xlabel('n');ylabel('Si Wt%');
grid on;

fprintf('\nPlot the Si Content after mapping.\n');
fprintf('Program paused. Press enter to continue.\n');
pause;


% Transpose the data in order to meet the requirement of libsvm
fprintf('\n Initializing.......\n');
TS = TS';

[TSX,TSXps] = mapminmax(tsx);
TSXps.ymin = 1;
TSXps.ymax = 2;
[TSX,TSXps] = mapminmax(tsx,TSXps);
TSX = TSX';

%split the data into training and testing
n1 = length(TS)*0.7;
train_label = TS(1:n1,:);
train_data = TSX(1:n1,:);
test_label = TS(n1+1:end,:);
test_data = TSX(n1+1:end,:);
%% ======================= First training =========================
fprintf('Begin the two round regressions to tune the parameter.\n');
fprintf('Program paused. Press enter to continue.\n');
pause;

% Find the optimize value of c,g paramter
% Approximately choose the parameters:
% the scale of c is 2^(-5),2^(-4),...,2^(10)
% the scale of g is 2^(-5),2^(-4),...,2^(5)
[bestmse,bestc,bestg] = svmregress(train_label,train_label,-5,10,-5,5,3,1,1,0.0005);

% Display the approximate result
disp('Display the approximate result');
str = sprintf( 'Best Cross Validation MSE = %g Best c = %g Best g = %g',bestmse,bestc,bestg);
disp(str);
%% ====================== Second training =========================
fprintf('\nFinish the first round tuning and begin the final round regression and print the final parameters.\n');
fprintf('Program paused. Press enter to continue.\n');
pause;

[bestmse,bestc,bestg] = svmregress(train_label,train_data,0,10,-2,10,3,0.3,0.3,0.0005);

disp('Display the final parameter result');
str = sprintf( '\nBest Cross Validation MSE = %g Best c = %g Best g = %g\n',bestmse,bestc,bestg);
disp(str);

fprintf('\nProgram paused. Press enter to continue.\n');
%% ======================= Predict ================================
fprintf('Predict the Si Content of the test data and compare to the truth value.\n');
pause;

%Do training by using svmtrain of libsvm
cmd = ['-c ', num2str(bestc), ' -g ', num2str(bestg) , ' -s 3 -p 0.01'];
model = svmtrain(train_label,train_data,cmd);

%Do predicting by using svmpredict of libsvm
predict= svmpredict(test_label,test_data,model);
predict = mapminmax('reverse',predict,TSps);

% Display the result of SVM Regression
str = sprintf( 'MSE = %g R = %g%%',mse(2),mse(3)*100);
disp(str);

figure;
hold on;
plot(original,'LineWidth',1);
plot(predict(3:end,:),'r','LineWidth',1);
legend('Original Si Content','Predict Si Content','FontSize',10);xlabel('n');ylabel('Si Wt%');
hold off;
grid on;
snapnow;