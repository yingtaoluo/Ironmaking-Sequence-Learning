%% Add Paths
addpath ([pwd filesep 'common']);
addpath ([pwd filesep 'common/minFunc']);
addpath ([pwd filesep 'gradientChecks']);
addpath ([pwd filesep 'objFunc']);
