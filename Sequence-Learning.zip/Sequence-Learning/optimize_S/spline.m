clear; clc;
load data.mat
X1 = Si(1:999);      % Si_pre1
X4 = coal(1:999);    % PML_pre1
X = [X1 X4];
Y = S(2:1000);
count = 0;
for i = 0.2:0.01:1.3
    for j = 0.1:0.5:17
        count = count + 1;
        X_new(count,:) = [i j];      % 111 * 34
        x1 = X1 - X_new(count,1);
        x2 = X4 - X_new(count,2);
        x  = x1.^2 + x2.^2;
        temp = (find(x == min(x)));
        Y_new(count,:) = sum(Y(temp)) / size(temp,2);
    end
end
min = min(Y_new);
fprintf('the minmum value of S content:%d\n',min);
T = find(Y_new == min);
fprintf('[Si]             [PML]\n');
for k = 1:size(T,1)
    j(k) = floor(T(k) / 111);
    i(k) = T(k) - 111 * j(k);
    fprintf('[%d    %d]\n',0.2 + 0.01*i(k) , 0.1 + 0.5*j(k));
end
    
% 3-D figure
X_1 = 0.2:0.01:1.3;
X_2 = 0.1:0.5:17;
[X_1 X_2] = meshgrid(X_1 , X_2);
Y_new = reshape(Y_new, 111, 34);
% spline interpolation
X1 = 0.2:0.01:1.3;
X2 = 0.1:0.01:17;
[X1 X2] = meshgrid(X1 , X2);
Z = interp2(X_2',X_1',Y_new,X1,X2,'spline');
figure(1)
Z(Z < 0) = 0;
mesh(X1,X2,Z);xlabel('Si');ylabel('PML');zlabel('S');
set(gca,'ztick',[0],'zticklabel',[0]);
title('[S] Content');